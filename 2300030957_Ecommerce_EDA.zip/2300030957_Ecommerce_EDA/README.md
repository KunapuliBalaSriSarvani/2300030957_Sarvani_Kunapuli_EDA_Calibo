# E-Commerce Data Analysis and Data Quality Assessment

## About the Project

This project focuses on analyzing and cleaning a messy e-commerce dataset using Python. The main purpose of the analysis is to understand the quality of the data, identify problems such as missing values, duplicate records, inconsistent categories and possible outliers, and prepare the dataset for further analysis.

The dataset contains information related to customers, orders, products, payments, ratings, delivery and order amounts.

## Tools Used

- Python
- Pandas
- Matplotlib
- Seaborn
- Jupyter Notebook

## What I Did

The dataset was first explored to understand its structure, dimensions, data types and statistical properties. Missing values, duplicate records, inconsistent categorical values and possible outliers were then identified and handled appropriately.

I also performed data consistency checks by comparing the expected order amount with the existing `Total_Amount`.

After cleaning the data, I performed univariate, bivariate and multivariate analysis using Seaborn and Matplotlib. Correlation analysis and different visualizations were used to understand relationships between the variables.

## Visualizations

The analysis includes:

- Histograms
- KDE plots
- Boxplots
- Countplots
- Scatterplots
- Barplots
- Violin plots
- Pairplot
- Correlation heatmap

Each visualization is followed by an interpretation to explain what can be understood from the graph.

## Files

- `Ecommerce_EDA_Kunapuli_Bala_Sri_Sarvani.ipynb` – Complete analysis notebook
- `messy_ecommerce_15000_student_practice.csv` – Original dataset
- `cleaned_ecommerce_dataset.csv` – Cleaned dataset
- `README.md` – Project overview

## Conclusion

The project helped me understand the complete process of working with a real-world messy dataset, starting from data-quality checking and cleaning to visualization, correlation analysis and business insights. The cleaned dataset can be used for further exploratory data analysis.